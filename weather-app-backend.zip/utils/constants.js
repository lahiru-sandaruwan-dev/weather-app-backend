const Constant = {
    API: {
        PREFIX: "/api/v1"
    },
    ROLE: {
        ADMIN: "admin",
        USER: "user"
    },
}

module.exports = Constant